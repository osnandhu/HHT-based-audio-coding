file=input('filename: ','s')
eval(['load ' file])
varname=input('variable name: ','s')
eval(['signal=' varname ';']);
[f c]=size(signal)
startpoint=input('first sample position: ')
numsamples=input('numberofsamples: ')
resol=input('resolution (dB) (normally between 40 and 60): ')
if isempty(resol)
    resol=40
end
overlap=input('Percentage of the window to be overlapped: ')
if isempty(overlap)
    overlap=10
end
minsize=input('minimum size of the first window: ')
if isempty(minsize)
    minsize=6000
end
minosc_partial=input('minimum number of oscilations at intermediate stages: ')
if isempty(minosc_partial)
    minosc_partial=10
end
minosc_absolute=input('minimum number of oscilations at last stage: ')
if isempty(minosc_absolute)
    minosc_absolute=2
end
[IMF,minsize,NUM_IMF, telapsed]=SWEMD_LS(signal,startpoint,numsamples, resol, overlap,minsize,10,2);