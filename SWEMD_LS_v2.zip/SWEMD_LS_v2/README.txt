1) Write the .mat in the this folder
2) Execute the batch.m file to be guided or directly the SWEMD_LS function if you prefer.
   The batch file ask you for the filename and the variable name to be analyzed (and the rest of parameters).
   
