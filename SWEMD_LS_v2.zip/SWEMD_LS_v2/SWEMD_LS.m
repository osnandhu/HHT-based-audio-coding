%%  This program  performs the empirical mode decomposition using Sliding Windows  for long signals, accordingly
%  to the paper:
% A Sliding Window Empirical Mode Decomposition for Long Signals Algorithm
% Sensors & Transducers, Vol. 204, Issue 9, September 2016, pp. 21-28
%   Authors: Jose Luis Sanchez de la Rosa (jsanrosa@ull.edu.es),
%                Manuel Ortigueira (mdo@fct.unl.pt),
%                Raul Rato (r.rato@fct.unl.pt) and Juan Trujillo (jtrujill@ullmat.es)
% ---------------------------------------------------------------------------------------------

% STMED v0.    2017 May the 5th



function [IMF,minsize,NUM_IMF, telapsed]=SWEMD_LS(Y,SP,SIZE, resol, overlap,minsize,MIN_OSC_partial,MIN_OSC_abs)
% STEMD(Y,SP,SIZE, resol, overlap,minsize,MIN_OSC_partial,MIN_OSC_abs)
% input parameters: 
% Y:   Signal to be analysed.
% SP: Starting point. It can be used to avoid transient responses. Z=Y(SP:end) is the signal which will be decomposed.
% SIZE: Length of the signal to be analysed
% resol - Resolution (in DBs: 10*log(WSignal/Bias energy))- normally between 40 and 60 dB 
% resid - Residual energy (in DBs: 10*log (WSignal/WqResidual))- normally between 40 and 60 dB
% overlap: Percentage of the window to be overlapped.
% minsize: Minimum size of the starting window. It is used to avoid an excesive number of windows in the first step
%              limit=minsize*2
% MIN_OSC_partial: Partial Limit number of oscilations during intermediate steps.
%               Once reached, the window size will be duplicated. 
% MIN_OSC_abs: Absolute limit number of oscilations for the last step. Once reached, the whole EMD is stopped.               
%    
%

%% 1) Check input and output arguments
close all
pause(1)
if(nargin<8), error('ParabEmd: Use with 8 inputs.'), end
if(nargout>4), error('ParabEmd: Use with just 4 outputs.'), end

if isempty(SP)
    SP=1;
end
if isempty(SIZE)
    SIZE=length(Y);
end
if isempty(resol)
    resol=40;
end
qAlfa=1;
resid=resol;
if isempty(overlap)
    overlap=10;
end
if isempty(minsize)
    minsize=6000;
end
if isempty(MIN_OSC_partial)
    MIN_OSC_partial=10;
end
if isempty(MIN_OSC_abs)
    MIN_OSC_abs=2;
end
                [a b]=size(Y)

if (a>1 & b>1)
                display('The input must be a row vector')
elseif (a==1 & b>1)
    Y=Y';
                [a b]=size(Y);
                display('column vector transposed to row vector')
end



%% 2) Initialization
% 2a) Input signal
    Z=Y(SP:SP+SIZE-1);
                figure
                plot(Z)
% 2b)  Starting windowsize. Determine the starting window size from the lenght
% of the signal to be analysed and the lower size allowed.
    [winsize,Tamfinal] =  InitialLength_calculation(SIZE,minsize);
    Z=Z(1:Tamfinal);
    SIZE=length(Z);
close all

% 2c) Residual window length
    [N,Nfinal,minsize,winsizelast,SamplesOverlap,RW,RWpercent] = ResidualLength(SIZE,winsize,overlap);
                
%%  ------------------------------ OUTER LOOP -----------------
                [a b]=size(Y);
                [a b]=size(Z);
                tstart = tic;
    [IMF] =  OUTERLOOP(Z,SIZE,winsize,overlap,resol,qAlfa,MIN_OSC_partial,MIN_OSC_abs);
                telapsed = toc(tstart);
    [a NUM_IMF]=size(IMF);
    eval(['save SWEMD_LS' num2str(resol)])
end
%
%
%
%
%
%% subfunctions
function [InitialLength,Tamfinal] = InitialLength_calculation(Size,minsize)
% [StartLength] = minsize_calculation(Size,minsize)
% Compute the initial window size. It must have a length which satisfies:
% 1) The total length of the signal must be a power of two of the initial
% window size
% 2) It must be bigger than minsize.
limit=minsize*2;
InitialLength=Size;
power2=1;
        while InitialLength>=limit
            InitialLength=fix(InitialLength/2);
            power2=power2*2;
        end
        Tamfinal=InitialLength*power2;
end
function [N,SamplesOverlap,IntLength] = WinNumber_calculation(Size,winsize,overlap)
% [N,SamplesOverlap,IntLength] = WinNumber_calculation(Size,winsize,overlap)
% Input:
%               L= Length of the signal
%               winsize= Window Size               
%               overlap= %  que representa el solape respecto al n�mero de puntos
%               de la ventana.
%  Output:
%  N= Number of windows with length winsize that fits in length Size
%       (considering the overlap region)
%  SamplesOverlap = Number of samples in the overlap region.
%  IntLength= Length corresponding to the m�ximum integer number (N) of
%  windows that fits in the length of the signal.

SamplesOverlap=fix(winsize*overlap/100);  % Samples in the overlap region.
N=fix((Size-SamplesOverlap)/(winsize-SamplesOverlap));
IntLength=N*(winsize-SamplesOverlap)+N;
end
function [N,Nfinal,winsizeold,winsizefinal,SamplesOverlap,RW,RWpercent] = ResidualLength(Size,winsize,overlap)
% [N,winsizeold,Nfinal,winsizefinal,SamplesOverlap,RWpercent,RW] = ResidualLength(Size,winsize,overlap)
% Input:
%               Size= Length of the signal
%               winsize= window length               
%               overlap=  percentage of the window length to be overlapped.
% Output:
%               N  = Integer number of windows that fits in the length of
%               the signal.
%               Nfinal = Final number of windows. Equal to N if the
%               residual samples are assigned to the last window. Increased
%               by one if it is necessary a new window to fit the whole
%               signal length.
%               winsizeold = Previous window size.
%               winsizefinal= Size of the last window.
%               Samples overlap: Number of samples in the overlap region
%               RW = Number of the residual samples
%               RWpercent = Ratio between residual samples and winsize
format compact
        i=1;
        INI=1;
        FIN=winsize;
        winsizeold=winsize;  % Backup or winsize
        [N,SamplesOverlap,IntLength] = WinNumber_calculation(Size,winsize,overlap);
        RW=Size-IntLength; % Number of residual samples
        RWpercent=100*RW/winsize; % Ratio between residual samples and winsize.
   
        % If the number of residual samples is bigger than 50% of winsize,
        % a new window with smaller size is created. Else, the residual
        % samples are added to the last window.
         if RWpercent >=50
            winsizefinal=RW+SamplesOverlap;    Nfinal=N+1;
         else            
            Nfinal=N;            
            if Nfinal==1
                winsizefinal=winsize;  
            else
                winsizefinal=winsize-SamplesOverlap+RW;  
            end            
         end
end

%% OUTERLOOP
function [IMF] = OUTERLOOP(x,L,winsize,k,resol,qAlfa,MIN_OSC_1,MIN_OSC_end)
            % [IMF] =  OUTERLOOP(x,L,winsize,k,resol,qAlfa,MIN_OSC_1,MIN_OSC_end)
            % This loop computes the whole set of IMF's, checks:
            % 1) The number of oscillations to determine when to finish the
            % decomposition
            %      2) While it is running, the numberof oscillations are checked
            %           to determine when to increase the window size          
            % input parameters
            % x = Signal
            % L= length of the signal
            % winsize = window length
            % k = percentage overlap
            % resol= resolution in dB to determine when to stop the IMF
            % calculation
            % qAlfa =
            % MIN_OSC_1=     Stopping parameter to change the window size.
            % MIN_OSC_end= Stopping parameter to end the decomposition.

% -------------------------------------------------------------------------

            %% Initialization
            [a b]=size(x);
            Lx=length(x);
            Z=x;
            Wx= Z'*Z; % Energy of the original signal
            WZ=Wx;
                       
            QOSC=1E5; %Initial number of oscilations. 
            [N,Nfinal,winsize,winsizefinal,SamplesOverlap,RW,RWpercent] = ResidualLength(L,winsize,k);
            
            p=1;
            errorsalida=0;

            
            
%%  WHILE LOOP            
            while (QOSC>MIN_OSC_end && winsize<=L) % While loop until the window size equals the whole length and the number of oscillations fall below a threshold
                    [Y2 RESIDUAL QOSC IT DbqResol] =sliding(Z,L,winsize, SamplesOverlap, winsizefinal,N,Nfinal,resol,qAlfa);
                    Wzold=WZ; % Energy of the signal
                    Wr=RESIDUAL'*RESIDUAL; % Energy of the RESIDUAL
                    if (Wr)>0
                            qDbResid= 10*log10(Wx/(Wr));
                    else
                            qDbResid = Inf
                    end
                    Z=RESIDUAL;
                    WZ= Z'*Z;
                    IMF(:,p)=Y2;
                    OSCILA(:,p)=QOSC;
                    if (QOSC<MIN_OSC_1 && winsize<L) % If number of oscillations is lower than partial threshold and winsize less than the whole signal length
                        % Duplicate the window size and calculate the
                        % overlap region and last window.
                        winsize=winsize*2;            
                        [N,Nfinal,winsize,winsizefinal,SamplesOverlap,RW,RWpercent] = ResidualLength(L,winsize,k);
                    end
                    p=p+1;
            end
            
            %% LEAVING THE OUTER LOOP
            A=sum(IMF')';
            [a b]=size(IMF);
            whos x A
            residual=x-A;
            IMF(:,b+1)=residual;

end

%% DEBUGGING
function [Y RESIDUAL QOSC IT DbqResol] =sliding(x,L,winsize, SamplesOverlap, winsizefinal,N,Nfin,resol,qAlfa)
% [Y RESIDUAL QOSC IT DbqResol] =sliding(x,L,winsize, SamplesOverlap, winsizefinal,N,Nfin,resol,qAlfa)
% Slides the window through the whole signal

                qResol=resol;
                qResid=resol;
                qAlfa;
                OSC=[];
                DBQ=[];
                 i=1;
                 INI=1;
                 FIN=winsize;

                 
                        if Nfin==1
                            winsize=winsizefinal;
                            FIN=winsizefinal;
                            X_windowed=x(INI:FIN);

                
                % oscilation defines the number of iterations needed to
                % reach the stopping criteria. The rest of the sliding
                % windows must iterate exactly that number of times.
                [rP1 oscilation IT DbqResol]= rPEmdFirst (X_windowed, qResol, qResid, qAlfa);
                                QOSC=oscilation;
                                Y=rP1;
                            %---------------------------------------------------------------------------------

                        else
                            if Nfin>=2
                                for i=1:Nfin-1
                                    % 1) The first stage is to change the starting point of the window
                                    if i==1
                                        %---------------------------------------------------------------------------------
                                            X_windowed=x(INI:FIN);
                                            % First sliding window calculation of the IMF.
                                            [rP1 oscilation IT DbqResol]= rPEmdFirst (X_windowed, qResol, qResid, qAlfa);
                                            OSC=[OSC oscilation];
                                            %Y=rP1;
                                            Y=rP1;
                                        %---------------------------------------------------------------------------------
                                    else
                                        INIold=INI;
                                        INI=INI+winsize-SamplesOverlap;
                                        FIN=INI+winsize-1;
                                        %---------------------------------------------------------------------------------
                                            % Esta rutina se ejecuta el n�mero de iteraciones que le indique rPemd_Lone
                                            X_windowed=x(INI:FIN);
                                            % Subsequent sliding windows calculations of the IMF. The
                                            % number of iterations is given by  IT.
                                            [rP2 IT2 oscilation2]= rPEmdLater (X_windowed, qResol, qResid, qAlfa,IT);
                                           OSC=[OSC oscilation2];
                                            ly=length(Y);
                                            Yold=Y;
                                            A1=Y(1:ly-SamplesOverlap);          % Left window non overlapping zone
                                            B1=rP2(SamplesOverlap+1:end);       % Right window non overlapping zone

                                            A2=Y(ly-SamplesOverlap+1:end);      % Left window overlapped zone
                                            B2=rP2(1:SamplesOverlap);           % Right window overlapped zone
                                            C2=(A2+B2)/2;                       % Average of the overlapped zone

                                            Y=[A1;C2;B1]; % TRANSPOSE FOR Y TO BE COLUMN VECTOR
                                            ly2=length(Y);

                                        %---------------------------------------------------------------------------------
                                    end
                                  end
                            end
                        end


                %---------------------------------------------------------------------------------
                %% Last window of the IMF calculation
                % In case more than one window exists
                if Nfin>1
                        i=i+1;
                        INI=INI+winsize-SamplesOverlap;
                        FIN=L;
                        %---------------------------------------------------------------------------------
                            X_windowed=x(INI:FIN);
                            [rP2 IT2 oscilation2]= rPEmdLater (X_windowed, qResol, qResid, qAlfa,IT);      
                            OSC=[OSC oscilation2];
                            Yold=Y;
                            ly=length(Y);
                            A1=Y(1:ly-SamplesOverlap);          % Left window non overlapping zone
                            B1=rP2(SamplesOverlap+1:end);       % Right window non overlapping zone


                            A2=Y(ly-SamplesOverlap+1:end);      % Left window overlapped zone
                            B2=rP2(1:SamplesOverlap);           % Right window overlapped zone
                            C2=(A2+B2)/2;                       % Average of the overlapped zone

                            Y=[A1;C2;B1];
                            ly2=length(Y);
                            QOSC=min(OSC);
                end
                [e f]=size(Y);
                % The RESIDUAL of the EMD is calculated at the last stage.
                RESIDUAL=x-Y;                
end
