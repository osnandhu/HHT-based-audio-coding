%% INPUT PARAMETERS
%%The batch program ask your for the next variables
% 1) file: Filename (.mat) with data to be analyzed
% 2) varname: Name of the variable which contains the signal to be analyzed
% 3) startpoint: Position of the first sample. 
% 4) numsamples: Number of samples.
%      Startpoint and numsamples allows us to analyze a selected epoch of the
%      signal (to discard transitories at the begining, for example).
% 5) resol: resolution in dB to stop the shifting procedure. Default
% value=40.
% 6) overlap: Percentage of the signal which is overlapped by each side. By
% default is 10. 
% 7) minsize: minimum size of the first window. That parameter is necessary
% to avoid an excesive number of windows. Recommended values are around
% 5.000 or 6.000 samples.
% 8) minosc_partial: If during the calculation, the minimum number of
% oscilations are reached, the window size is enlarged by a factor of 2.
% 9) minosc_absolute: If the minimum number of oscilations (absolute) are
% reached, the EMD is stopped.

%% OUPUT PARAMETERS
% 1) IMF:            Obtained IMF's 
% 2) minsize:      Number of samples of the smaller window.
% 3) NUM_IMF: Number of IMF
% 4) telapsed:    Elapsed time for the calculation of the EMD.
[IMF,minsize,NUM_IMF, telapsed]=SWEMD_LS(signal,startpoint,numsamples, resol, overlap,minsize,10,2);